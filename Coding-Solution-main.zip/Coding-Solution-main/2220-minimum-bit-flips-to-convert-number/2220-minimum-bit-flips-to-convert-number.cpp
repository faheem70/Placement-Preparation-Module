class Solution {
public:
    int minBitFlips(int start, int goal) {
        int i,j,count=0;
        while(start!=goal){
            i=start&1;
            j=goal&1;
            if(i!=j)count++;
            start=start>>1;
            goal=goal>>1;
        }
        return count;
    }
};