class Solution {
public:
    string convertToBase7(int num) {
        if(num==0)return "0";
        int ans=0;
        int flag=0;
        if(num<0)
            flag=1;
        string res;
        num=abs(num);
        while(num!=0){
            ans=num%7;
            num/=7;
            res+= to_string(ans);
        }
        reverse(res.begin(),res.end());
        if(flag==1)
        {
            res.insert(res.begin(),'-');
        }
        return res;
       
    }
};