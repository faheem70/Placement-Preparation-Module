class Solution {
public:
    set<string>st;
    bool solve(int i,string s, vector<int>&dp){
        if(i>=s.length()){
            return true;
        }
        if(dp[i]!=-1)return dp[i];
        if(st.find(s)!=st.end())return true;
        
        for(int j=1;j<s.length();j++){
            string temp=s.substr(i,j);
            if(solve(i+j,s,dp) && st.find(temp)!=st.end())return dp[i]=true;
        }
        return dp[i]=false;
    }
    bool wordBreak(string s, vector<string>& wordDict) {
        int n = s.length();
        vector<int>dp(n,-1);
        for(auto it:wordDict){
            st.insert(it);
        }
        return solve(0,s,dp);
    }
};