class Solution {
public:
    int solve(int ind,vector<int>nums,int buy, vector<vector<int>>&dp)
    {
        int n = nums.size();
        if(ind>=n)return 0;
        if(dp[ind][buy]!=-1)return dp[ind][buy];
        int profit;
        if(buy==0)
            profit = max(0+solve(ind+1,nums,0,dp), -nums[ind]+solve(ind+1,nums,1,dp));
        if(buy ==1)
            profit = max(0+solve(ind+1,nums,1,dp), nums[ind]+solve(ind+2,nums,0,dp));
        
        dp[ind][buy]=profit;
        return dp[ind][buy];
    }
    int maxProfit(vector<int>& nums) {
        int n = nums.size();
        vector<vector<int>>dp(n,vector<int>(n,-1));
        int ans = solve(0,nums,0,dp);
        return ans;
    }
};