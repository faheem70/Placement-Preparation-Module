class Solution {
public:
    int solve(int i,int amt,vector<int>&coins ,vector<vector<int>>&dp){
        if(amt==0)return 1;
        
        if(i==coins.size())return 0;
      
        if(dp[i][amt]!=-1)return dp[i][amt];
          
        if(coins[i]>amt)
            return dp[i][amt]=solve(i+1,amt,coins,dp);
        
        int pick = solve(i,amt-coins[i],coins,dp);
        int notPick = solve(i+1,amt,coins,dp);
        
        return dp[i][amt]=pick+notPick;
    }
    int change(int amount, vector<int>& coins) {
        int n =coins.size();
        
        vector<vector<int>>dp(n+1,vector<int>(amount+1,-1));
        
        return solve(0,amount,coins,dp);
    }
};