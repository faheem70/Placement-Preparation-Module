class Solution {
public:
    void solve(int idx,int k,int x,vector<int>&res,vector<vector<int>>&ans)
    {
        if(x==0)
        {
            if(k==0)ans.push_back(res);
            return;
        }
        for(int i=idx;i<=9;i++)
        {
            if(x>=i && k>0)
            {
                res.push_back(i);
                k--;
                solve(i+1,k,x-i,res,ans);
                res.pop_back();
                k++;
            }
            
        }
    }
    vector<vector<int>> combinationSum3(int k, int n) {
        vector<vector<int>>ans;
        vector<int>res;
        solve(1,k,n,res,ans);
        return ans;
    }
};