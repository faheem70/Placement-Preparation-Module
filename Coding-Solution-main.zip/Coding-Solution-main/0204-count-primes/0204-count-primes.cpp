class Solution {
public:
    int sieve(int n){
        vector<int>prime(n,1);
        int count=0;
        for(int i=2;i*i<n;i++){
            ////if(prime[i]==true){
                for(int j=i*i;j<n;j+=i)
                {
                    prime[j]=0;
                }
           // }
        }
        for(int i=2;i<n;i++)
        {
            if(prime[i]==1)count++;
        }
        return count;
    }
    int countPrimes(int n) {
        return sieve(n);
    }
};