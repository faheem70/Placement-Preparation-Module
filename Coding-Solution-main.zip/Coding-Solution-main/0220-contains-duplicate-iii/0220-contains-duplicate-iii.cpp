class Solution {
public:
    bool containsNearbyAlmostDuplicate(vector<int>& nums, int indexDiff, int valueDiff) {
        vector<pair<int,int>>p;
        for(int i=0;i<nums.size();i++)
        {
            p.push_back({nums[i],i});
        }
        sort(p.begin(),p.end());
        for(int i=0;i<nums.size();i++)
        {
            for(int j = i+1;j<nums.size();j++){
                
                if(p[i].first+valueDiff>=p[j].first)
                {
                    if(abs(p[i].second-p[j].second)<=indexDiff)
                    {
                        return true;
                    }
                }
                else{
                    break;
                }
            }
        }
        return false;
    }
};