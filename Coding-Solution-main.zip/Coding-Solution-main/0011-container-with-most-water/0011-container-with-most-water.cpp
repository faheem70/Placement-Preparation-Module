class Solution {
public:
    int maxArea(vector<int>& height) {
        int i=0,j=height.size()-1;
        int cnt=0;
        while(i<j){
            int res= min(height[i],height[j]);
            
            cnt = max(cnt,(j-i)*res);
            
            while(height[i]<=res && i<j )i++;
            
            while(height[j]<=res && i<j)j--;
        }
        return cnt;
    }
};