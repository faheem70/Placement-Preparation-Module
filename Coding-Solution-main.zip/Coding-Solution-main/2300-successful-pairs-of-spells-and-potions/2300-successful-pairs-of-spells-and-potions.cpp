class Solution {
public:
    vector<int> successfulPairs(vector<int>& spells, vector<int>& potions, long long success) {
        int n = potions.size();
        int m = spells.size();
        vector<int>ans(m,0);
        
        sort(potions.begin(),potions.end());
        
        for(int i=0;i<m;i++)
        {
            int s=0,e=n-1;
            while(s<=e){
                int mid=(s+e)>>1;
                if((long long)spells[i]*(long long)potions[mid]>=success){
                    e=mid-1;
                }
                else{
                    s=mid+1;
                }
            }
            ans[i]=potions.size()-1-e;
        }
        return ans;
        
    }
};