class Solution {
public:
    int bulbSwitch(int n) {
        int cnt=0;
        for(int i=1;i<=sqrt(n);i++){
            cnt++;
        }
        return cnt;
    }
};