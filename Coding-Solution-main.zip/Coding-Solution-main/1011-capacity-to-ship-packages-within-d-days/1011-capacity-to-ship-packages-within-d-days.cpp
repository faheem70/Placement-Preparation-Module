class Solution {
public:
    bool solve(int mid, vector<int>nums, int n, int D){
        int sum=0;
        int days=1;
        for(int i=0;i<n;i++){
            if(sum+nums[i]<=mid)sum+=nums[i];
            else{
                sum=nums[i];
                days++;
            }
        }
        if(days<=D)return true;
        return false;
    }
    int shipWithinDays(vector<int>& nums, int days) {
        int n = nums.size();
        int sum=0,maxi=0;
        for(int i=0;i<nums.size();i++){
            if(nums[i]>maxi) maxi=nums[i];
                sum+=nums[i]; 
        }
        int l=maxi;
        int e= sum;
        int ans;
        while(l<=e)
        {
            int mid = l+(e-l)/2;
            if(solve(mid,nums,n,days)){
                ans=mid;
                e=mid-1;
            }
            else{
                l=mid+1;
            }
        }
        return ans;
    }
};