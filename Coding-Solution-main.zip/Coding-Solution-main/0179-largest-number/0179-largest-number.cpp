class Solution {
public:
    
    string largestNumber(vector<int>& nums) {
         string res;
        sort(nums.begin(),nums.end(),[](const int &n,int&m){
             return to_string(m)+to_string(n)<to_string(n)+to_string(m);
        });
        
        for(int i=0;i<nums.size();i++)
        {
            res+=to_string(nums[i]);
        }
        if(res[0]=='0')
            return "0";
        return res;
    }
};