class Solution {
public:
    string reverseVowels(string s) {
        int ch[256]={0};
        ch['a']=1;
        ch['i']=1;
        ch['e']=1;
        ch['o']=1;
        ch['u']=1;
        ch['A']=1;
        ch['I']=1;
        ch['E']=1;
        ch['O']=1;
        ch['U']=1;
        int i=0,j=s.size()-1;
        while(i<j)
        {
            while(i<j && ch[s[i]]==0)i++;
            while(i<j && ch[s[j]]==0)j--;
            
            swap(s[i],s[j]);
            i++,j--;
        }
        return s;
    }
};