class Solution {
public:
    int minimumDeviation(vector<int>& nums) {
        int n = nums.size();
        int maxi = INT_MIN;
        int mini = INT_MAX;
        
        for(int i=0;i<n;i++)
        {
            if(nums[i]%2!=0)nums[i]*=2;
            
            maxi = max(maxi,nums[i]);
            mini=min(mini,nums[i]);
        }
        int min_d = maxi-mini;
        
        priority_queue<int>q;
        for(int i=0;i<n;i++)
        {
            q.push(nums[i]);
        }
        
        while(q.top()%2==0){
            int top = q.top();
            q.pop();
            min_d = min(min_d,top-mini);
            
            top/=2;
            mini=min(top,mini);
            q.push(top);
        }
        min_d = min(min_d, q.top()-mini);
        return min_d;
    }
};