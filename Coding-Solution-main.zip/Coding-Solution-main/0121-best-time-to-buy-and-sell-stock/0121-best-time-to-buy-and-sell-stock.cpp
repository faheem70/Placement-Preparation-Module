class Solution {
public:
    
    int maxProfit(vector<int>& nums) {
        int maxPro=0;
        int mini=nums[0];
        for(int i=1;i<nums.size();i++){
            int currPro=nums[i]-mini;
            maxPro=max(maxPro,currPro);
            mini=min(mini,nums[i]);
        }
        return maxPro;
    }
};