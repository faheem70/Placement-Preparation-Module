class Solution {
public:
    int maxRotateFunction(vector<int>& nums) {
        int sum=0,f=0;
        int maxi=0;
        vector<int>dp(nums.size());
        for(int i=0;i<nums.size();i++)
        {
            sum+=nums[i];
            f+=i*nums[i];
        }
         dp[0]=f;
        maxi=dp[0];
        for(int i=1;i<nums.size();i++)
        {
            dp[i]=dp[i-1]+sum-nums.size()*nums[nums.size()-i];
            maxi=max(maxi,dp[i]);
        }
        return maxi;
    }
};