class Solution {
public:
    void solve(int i,vector<int>&arr,vector<int>&ans,int k,int &res){
        if(i==arr.size()){
            int maxi=INT_MIN;
            for(int j=0;j<k;j++)
            {
                maxi=max(maxi,ans[j]);
            }
            res=min(res,maxi);
            return;
        }
        for(int j=0;j<k;j++)
        {
            ans[j]+=arr[i];
            solve(i+1,arr,ans,k,res);
            ans[j]-=arr[i];
        }
    }
    int distributeCookies(vector<int>& cookies, int k) {
      vector<int>ans(k,0);
     int res=INT_MAX;  
     solve(0,cookies,ans,k,res);
        return res;
        
    }
};