class Solution {
public:
    string restoreString(string s, vector<int>& indices) {
        vector<pair<int,char>>pq;
        string ans="";
        for(int i=0;i<indices.size();i++)
        {
            pq.push_back({indices[i], s[i]});
        }
        
        sort(pq.begin(),pq.end());
      
        for(int i=0;i<s.size();i++)
        {
              cout<<pq[i].second;
            ans+=pq[i].second;
        }
        return ans;
    }
};