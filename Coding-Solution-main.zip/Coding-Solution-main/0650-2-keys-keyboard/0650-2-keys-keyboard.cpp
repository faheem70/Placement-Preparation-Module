class Solution {
public:
    int minSteps(int n) {
        int prime[13]={2,3,5,7,11,13,17,19,23,29,31,37,41};
        if(n<=5)
        {
            if(n==1)return 0;
            else{
                return n;
            }
        }
        for(auto it:prime)
        {
            if((n%it)==0)return it+minSteps(n/it);
        }
        return n;
    }
};