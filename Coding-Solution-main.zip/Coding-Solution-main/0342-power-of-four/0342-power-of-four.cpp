class Solution {
public:
    bool isPowerOfFour(int n) {
        int x=31;
        while(x>=0)
        {
            if(pow(4,x)==n)return true;
            x--;
        }
        return false;
    }
};