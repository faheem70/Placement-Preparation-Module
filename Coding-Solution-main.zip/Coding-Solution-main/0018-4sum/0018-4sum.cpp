class Solution {
public:
    vector<vector<int>> fourSum(vector<int>& nums, int target) {
        vector<vector<int>>ans;
        sort(nums.begin(),nums.end());

        for(int i=0;i<nums.size();i++){
            long long target1=target-nums[i];
            for(int j=i+1;j<nums.size();j++){
                long long target2 = target1-nums[j];
                int s = j+1;
                int e = nums.size()-1;
                while(s<e)
                {
                    int sum = nums[s]+nums[e];
                    if(sum>target2){e--;
                    }
                    else if(sum<target2){s++;
                    }
                    else{
                      vector<int>res={nums[i],nums[j],nums[s],nums[e]};
                       
                      ans.push_back(res);
                      
                      while(s<e && nums[e]==res[3])e--;

                      while(s<e && nums[s]==res[2])s++;
                    }
                }
                while(j+1<nums.size() && nums[j]==nums[j+1])j++;
            }
            while(i+1<nums.size() && nums[i]==nums[i+1])i++;
        }
        return ans;
    }
};