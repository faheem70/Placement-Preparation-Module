class Solution {
public:
    int solve(int n,int i){
        if(i==0 || n==0)return 1;
        if(i>n)return solve(n,i-1);
        return max(i*solve(n-i,i),solve(n,i-1));
    }
    int integerBreak(int n) {
        return solve(n,n-1);
    }
};