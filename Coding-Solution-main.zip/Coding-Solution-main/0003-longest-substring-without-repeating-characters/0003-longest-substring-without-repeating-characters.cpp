class Solution {
public:
    int lengthOfLongestSubstring(string s) {
        int n = s.length();
        set<char>st;
        int i=0,j=0,maxi=0;
        while(j<n)
        {
            if(st.count(s[j])==0){
                st.insert(s[j++]);       
                maxi=max(maxi,(int)st.size());
            }
            else{
                st.erase(s[i]);
                i++;
            }
        }
        return maxi;
    }
};