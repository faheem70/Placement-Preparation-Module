class Solution {
public:
    bool compare(pair<int,int>a,pair<int,int>b){
        if(a.first==b.first)return a.second<b.second;
        return a.first<b.first;
    }
    long long findScore(vector<int>& nums) {
        vector<pair<int,int>>p;
        
        for(int i=0;i<nums.size();i++){
            p.push_back({nums[i],i});
        }
        int n = nums.size();
        long long ans=0;
        sort(p.begin(),p.end());
        vector<int>vis(n,0);
        for(int i=0;i<n;i++)
        {
            long long x=p[i].first;
            long long y=p[i].second;
            if(!vis[y]){
                ans+=x;
                vis[y]=1;
                if(y-1>=0)vis[y-1]=1;
                if(y+1<n)vis[y+1]=1;
            }
        }
        return ans;
    }
};