class Solution {
public:
    int isWinner(vector<int>& player1, vector<int>& player2) {
        int sum1=0,sum2=0;
        int x1=0,x2=0;
        for(int i=0;i<player1.size();i++){
            sum1+=player1[i];
            sum2+=player2[i];
            
            if(x1){
                x1--;
                sum1+=player1[i];
            }
            if(x2){
                x2--;
                sum2+=player2[i];
            }
            if(player1[i]==10)
            {
                x1=2;
            }
            if(player2[i]==10)
            {
                x2=2;
            }
        }
        
        
        if(sum1>sum2)
        {
            return 1;
        }
        else if(sum1==sum2){
            return 0;
        }
        else return 2;
    }
};