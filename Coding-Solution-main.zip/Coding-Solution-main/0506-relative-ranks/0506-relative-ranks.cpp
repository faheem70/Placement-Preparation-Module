class Solution {
public:
    vector<string> findRelativeRanks(vector<int>& score) {
       
        int n = score.size();
         vector<string>ans(n);
         priority_queue<pair<int,int>>q;
        
        for(int i=0;i<n;i++)
        {
            q.push({score[i],i});
        }
        
        int i=1;
        while(!q.empty())
        {
            auto idx = q.top();
            q.pop();
            if(i>3)
            {
                ans[idx.second]=to_string(i);
            }
            if(i==1)
            {
                ans[idx.second]= "Gold Medal";
            }
            if(i==2)
            {
                ans[idx.second] = "Silver Medal";
            }
            if(i==3)
            {
                ans[idx.second] = "Bronze Medal";
            }
            i++;
        }
        return ans;
    }
};