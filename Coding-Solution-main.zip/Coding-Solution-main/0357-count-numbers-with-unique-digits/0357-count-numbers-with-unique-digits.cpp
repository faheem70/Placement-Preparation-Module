class Solution {
public:
    int countNumbersWithUniqueDigits(int n) {
        if(n==0)return 1;
        int cnt=10;
        int ans=9;
        int curr=9;
        while(n-->1 && ans)
        {
            curr*=(ans--);
            cnt+=curr;
        }
        return cnt;
    }
};