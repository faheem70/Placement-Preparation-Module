class Solution {
public:
    int characterReplacement(string s, int k) {
        vector<int>freq(26,0);
        int n =s.size();
        int i=0,j=0;
        int maxi=0,ans=0;
        while(j<n){
            freq[s[j]-'A']++;
            maxi = max(maxi,freq[s[j]-'A']);
            if((j-i+1)-maxi>k)
            {
               ans=max(ans,(j-i));
                freq[s[i]-'A']--;
                i++;
            
                maxi=*(max_element(freq.begin(),freq.end()));
            }
            j++;
        }
        return max(ans,(j-i));
    }
};