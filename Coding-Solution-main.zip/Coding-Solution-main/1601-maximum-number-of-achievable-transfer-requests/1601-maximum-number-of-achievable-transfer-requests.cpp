class Solution {
public:
    int res=0;
    void solve(int i,vector<vector<int>>&nums, int n, vector<int>&ans,int count){
        if(i==nums.size()){
            for(int j=0;j<n;j++)
            {
                if(ans[j]!=0)return;
            }
            res=max(res,count);
            return;
        }
        
        ans[nums[i][0]]--;
        ans[nums[i][1]]++;
        solve(i+1,nums,n,ans,count+1);
        
        ans[nums[i][1]]--;
        ans[nums[i][0]]++;
        
        solve(i+1,nums,n,ans,count);
    }
    int maximumRequests(int n, vector<vector<int>>& requests) {
        vector<int>ans(n,0);
        solve(0,requests,n,ans,0);
        return res;
    }
};