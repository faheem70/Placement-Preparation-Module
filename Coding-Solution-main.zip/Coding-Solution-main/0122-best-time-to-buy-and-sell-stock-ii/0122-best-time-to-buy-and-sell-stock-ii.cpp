class Solution {
public:
    
    int maxProfit(vector<int>& nums) {
        int stock0=0;
        int stock1 = -nums[0];
        for(int i=1;i<nums.size();i++){
            int nstock0,nstock1;
            nstock0 = max(stock0,stock1+nums[i]);
            nstock1 = max(stock1,stock0-nums[i]);
            
            stock0=nstock0;
            stock1 = nstock1;
        }
        return stock0;
        
    }
};