class Solution {
public:
    int getSum(int a, int b) {
        while(b){
            unsigned int res = a&b;
            a^=b;
            b=res<<1;
        }
        return a;
    }
};