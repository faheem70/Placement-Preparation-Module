class Solution {
public:
    int lengthOfLIS(vector<int>& nums) {
        int n =nums.size();
        vector<int>num;
        for(auto it:nums)
        {
            if(num.empty() || num[num.size()-1]<it){
            num.push_back(it);
            }
            else{
                auto x = lower_bound(num.begin(),num.end(),it);
                *x=it;
            }
        }
        return num.size();
       
    }
};