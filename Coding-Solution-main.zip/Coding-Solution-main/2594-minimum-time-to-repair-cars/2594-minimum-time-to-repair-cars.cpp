class Solution {
public:
    long long repairCars(vector<int>& ranks, int cars) {
        long long i=0;
        long long j = 1e14;
        while(i<j)
        {
            long long mid = (i+j)/2;
            long long cnt=0;
            for(int i=0;i<ranks.size();i++)
            {
                cnt+=sqrt(mid/ranks[i]);
                //cout<<cnt<<endl;
            }
            if(cnt>=cars)j=mid;
            else i=mid+1;
        }
        return i;
    }
};