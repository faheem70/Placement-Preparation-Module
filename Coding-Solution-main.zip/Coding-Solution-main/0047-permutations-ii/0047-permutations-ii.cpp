class Solution {
public:
    void solve(int indx,int jdx,vector<vector<int>>&ans,vector<int>nums){
        if(indx==jdx-1)
        {
            ans.push_back(nums);
            return;
        }
       
        for(int k=indx;k<jdx;k++){
            if(indx!=k && nums[indx]==nums[k])continue;
            swap(nums[indx],nums[k]);
            solve(indx+1,jdx,ans,nums);
        }
    }
    vector<vector<int>> permuteUnique(vector<int>& nums) {
        vector<vector<int>>ans;
        //vector<int>res;
        sort(nums.begin(),nums.end());
        solve(0,nums.size(),ans,nums);
        return ans;
    }
};