class Solution {
public:
    int equalPairs(vector<vector<int>>& grid) {
        int cnt=0;
        int n = grid.size();
        int m = grid[0].size();
        map<vector<int>,int>mp;
        for(int i=0;i<n;i++)
        {
             mp[grid[i]]++;
        }
         
        for(int j=0;j<m;j++)
        {
            vector<int>ans;
            for(int i=0;i<n;i++)
            {
                ans.push_back(grid[i][j]);
            }
            cnt+=mp[ans];
        }
        return cnt;
    }
};