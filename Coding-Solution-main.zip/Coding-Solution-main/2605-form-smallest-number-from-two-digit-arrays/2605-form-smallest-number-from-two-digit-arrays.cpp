class Solution {
public:
    int minNumber(vector<int>& nums1, vector<int>& nums2) {
       map<int,int>m;
        for(int i=0;i<nums1.size();i++){
            m[nums1[i]]++;
        }
        int ans=INT_MAX;
        for(int i=0;i<nums2.size();i++){
            if(m.find(nums2[i])!=m.end()){
                ans=min(nums2[i],ans);
            }
        }
        if(ans!=INT_MAX)return ans;
        sort(nums1.begin(),nums1.end());
        sort(nums2.begin(),nums2.end());
        if(nums1[0]>nums2[0]){
            return ((nums2[0]*10)+nums1[0]);
        }
         return ((nums1[0]*10)+nums2[0]);
    
        
    }
};