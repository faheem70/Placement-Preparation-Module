class Solution {
public:
    void solve(int node,vector<vector<int>>&adj,vector<bool>&vis){
        //vis[node]=true;
        
        for(int it=0;it<adj.size();it++){
            if(!vis[it] && adj[node][it]==1){
                vis[it]=true;
                solve(it,adj,vis);
            }
        }
    }
    int findCircleNum(vector<vector<int>>& isConnected) {
        int ans=0;
        int n = isConnected.size();
        vector<bool>vis(n,false);
        for(int i=0;i<n;i++){
            if(!vis[i]){
                solve(i,isConnected,vis);
                ans++;
            }
        }
        return ans;
    }
};