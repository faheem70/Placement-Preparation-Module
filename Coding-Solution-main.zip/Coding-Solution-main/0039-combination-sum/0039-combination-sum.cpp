
class Solution {
public:
    void solve(int idx,int target,vector<int>nums, vector<int>&res, vector<vector<int>>&ans){
        if(idx==nums.size())
        {
            if(target==0)ans.push_back(res);
            return;
        }
        if(nums[idx]<=target){
            res.push_back(nums[idx]);
            solve(idx,target-nums[idx],nums,res,ans);
            res.pop_back();
        }
        solve(idx+1,target,nums,res,ans);
    }
    vector<vector<int>> combinationSum(vector<int>& nums, int target) {
        vector<vector<int>>ans;
        vector<int>res;
        sort(nums.begin(),nums.end());
         nums.erase(unique(nums.begin(),nums.end()),nums.end());
        solve(0,target,nums,res,ans);
        return ans;
    }
};