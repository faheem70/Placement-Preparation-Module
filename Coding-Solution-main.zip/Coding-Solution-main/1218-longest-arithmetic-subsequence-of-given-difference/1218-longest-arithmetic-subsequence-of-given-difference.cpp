class Solution {
public:
    int longestSubsequence(vector<int>& arr, int difference) {
       int n =arr.size();
        unordered_map<int,int>dp;
        
        int ans=1;
        for(auto &it:arr)
        {
 if(!dp.count(it - difference)) dp[it] = 1;
        else dp[it] = dp[it - difference] + 1;
        ans = max(ans, dp[it]); 
        }
        return ans;
    }
};