class Solution {
public:
    void solve(int st,string digits,vector<string>&ans,string str[],string res){
        if(st>=digits.size()){
            ans.push_back(res);
            return;
        }
        
        int idx=digits[st]-'0';
        string output=str[idx];
        for(int i=0;i<output.size();i++)
        {
            res.push_back(output[i]);
            solve(st+1,digits,ans,str,res);
            res.pop_back();
        }
    }
    vector<string> letterCombinations(string digits) {
        vector<string>ans;
        string res="";
        int n = digits.size();
        if(n==0)return ans;
        string str[10]={"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
        solve(0,digits,ans,str,res);
        return ans;
    }
};